# Launch with
#
# python app.py

from flask import Flask, render_template
import sys
import pickle

app = Flask(__name__)

@app.route("/")
def articles():
    """Show a list of article titles"""
    ## YOUR CODE HERE
    # articles = [[topic, filename, title, text],]
    
    return render_template('articles.html', articles=articles_list)


@app.route("/article/<topic>/<filename>")
def article(topic, filename):
    """
    Show an article with relative path filename. Assumes the BBC structure of
    topic/filename.txt so our URLs follow that.
    """
    ## YOUR CODE HERE
    file = topic+'/'+filename
    # recommended_l=[[topic, filename, title]]
    for item in recommended:
        if file in item.keys():
            recommended_l = item[file]
            print(recommended_l)
    for i in articles_list:
        if i[0] == topic and i[1] == filename:
            title = i[2]
            text = i[3].split('\n')
            break
    return render_template('article.html', title=title, text=text, recommended_l=recommended_l)


f = open('articles.pkl', 'rb')
articles_list = pickle.load(f)
f.close()
print(articles_list)

f = open('recommended.pkl', 'rb')
recommended = pickle.load(f)
f.close()
# you may need more code here or not

# for local debug
if __name__ == '__main__':
    app.run(debug=True)
